export { default } from './scripts/Main';
export { Native } from './scripts/NativeMain';
export { Smooth } from './scripts/Main';
